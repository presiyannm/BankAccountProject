﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    public class Account
    {
        private int id;
        private double balance;
        public Account(int id, double balance)
        {
            Id = id;
            Balance = balance;
        }
        public int Id
        {
            get { return id; }
            set
            {
                if (value > 0) id = value;
                else throw new Exception("Id cannot be negaitve or zero");
            }
        }
        public double Balance
        {
            get { return balance; }
            set
            {
                if (value >= 0) balance = value;
                else throw new Exception("Balance cannot be negative");
            }
        }
        public void Deposit(double amount)
        {
            Balance += amount;
        }
        public void Withdraw(double amount)
        {
            if (Balance - amount < 0)
            {
                throw new Exception("Insufficient balance");
            }
            else
            {
                Balance -= amount;
            }
        }
        public override string ToString()
        {
            return ($"Account ID{Id}, balance {Balance:F2} ");
        }

    }
}
