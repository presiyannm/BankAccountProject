﻿using System;

namespace BankAccount
{
    /// <summary>
    /// Represents a bank account with basic functionalities.
    /// </summary>
    public class Account
    {
        private int id;
        private double balance;

        /// <summary>
        /// Initializes a new instance of the <see cref="Account"/> class with specified ID and balance.
        /// </summary>
        /// <param name="id">The ID of the account.</param>
        /// <param name="balance">The initial balance of the account.</param>
        public Account(int id, double balance)
        {
            Id = id;
            Balance = balance;
        }

        /// <summary>
        /// Gets or sets the ID of the account.
        /// </summary>
        public int Id
        {
            get { return id; }
            set
            {
                if (value > 0) id = value;
                else throw new Exception("Id cannot be negative or zero");
            }
        }

        /// <summary>
        /// Gets or sets the balance of the account.
        /// </summary>
        public double Balance
        {
            get { return balance; }
            set
            {
                if (value >= 0) balance = value;
                else throw new Exception("Balance cannot be negative");
            }
        }

        /// <summary>
        /// Deposits the specified amount into the account.
        /// </summary>
        /// <param name="amount">The amount to be deposited.</param>
        public void Deposit(double amount)
        {
            Balance += amount;
        }

        /// <summary>
        /// Withdraws the specified amount from the account.
        /// </summary>
        /// <param name="amount">The amount to be withdrawn.</param>
        /// <exception cref="Exception">Thrown when the withdrawal amount exceeds the balance.</exception>
        public void Withdraw(double amount)
        {
            if (Balance - amount < 0)
            {
                throw new Exception("Insufficient balance");
            }
            else
            {
                Balance -= amount;
            }
        }

        /// <summary>
        /// Returns a string representation of the account details.
        /// </summary>
        /// <returns>A string containing the account ID and balance.</returns>
        public override string ToString()
        {
            return ($"Account ID {Id}, balance {Balance:F2} ");
        }
    }
}
