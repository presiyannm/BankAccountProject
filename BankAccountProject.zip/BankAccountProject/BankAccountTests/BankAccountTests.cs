using BankAccount;
namespace BankAccountTests
{
    [TestFixture]
    public class Tests
    {
        private Account account;
        [SetUp]
        public void Setup()
        {
            //Arrange
            account = new(1, 10);
        }

        [Test]
        public void TestIfDepositWorksCorrectly()
        {
            //Act
            account.Deposit(20);
            //Assert
            Assert.That(account.Balance, Is.EqualTo(30));
        }

        [Test]
        public void TestIfWithdrawWorksCorrectly()
        {
            //Act
            account.Withdraw(10);
            //Assert
            Assert.That(account.Balance, Is.EqualTo(0));
        }

        [Test]
        public void TestIfConstructorSavesValues()
        {
            //Assert
            Assert.That(account.Id, Is.EqualTo(1));
            Assert.That(account.Balance, Is.EqualTo(10));
        }

        [Test]
        public void TestExceptionIdNegativeOrZero()
        {
            //Act
            var ex = Assert.Throws<Exception>(() => account = new Account(-2, 5));
            //Assert
            Assert.That(ex.Message, Is.EqualTo("Id cannot be negaitve or zero"));
        }

        [Test]
        public void TestExceptionBalanceNegative() 
        {
            //Act
            var ex = Assert.Throws<Exception>(() => account = new Account(1, -25));
            //Assert
            Assert.That(ex.Message, Is.EqualTo("Balance cannot be negative"));
        }

        [Test]
        public void TestInsufficientBalance()
        {
            //Act
            var ex = Assert.Throws<Exception>(() => account.Withdraw(35));
            //Assert
            Assert.That(ex.Message, Is.EqualTo("Insufficient balance"));
        }
    }
}