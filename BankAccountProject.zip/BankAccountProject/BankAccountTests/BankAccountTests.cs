using BankAccount;
using NUnit.Framework;
using System;

namespace BankAccountTests
{
    /// <summary>
    /// Contains tests for the Account class from the BankAccount namespace.
    /// </summary>
    [TestFixture]
    public class Tests
    {
        private Account account;

        [SetUp]
        public void Setup()
        {
            // Arrange
            account = new Account(1, 10);
        }

        /// <summary>
        /// Tests if the Deposit method works correctly.
        /// </summary>
        [Test]
        public void TestIfDepositWorksCorrectly()
        {
            // Act
            account.Deposit(20);

            // Assert
            Assert.That(account.Balance, Is.EqualTo(30));
        }

        /// <summary>
        /// Tests if the Withdraw method works correctly.
        /// </summary>
        [Test]
        public void TestIfWithdrawWorksCorrectly()
        {
            // Act
            account.Withdraw(10);

            // Assert
            Assert.That(account.Balance, Is.EqualTo(0));
        }

        /// <summary>
        /// Tests if the constructor saves values correctly.
        /// </summary>
        [Test]
        public void TestIfConstructorSavesValues()
        {
            // Assert
            Assert.That(account.Id, Is.EqualTo(1));
            Assert.That(account.Balance, Is.EqualTo(10));
        }

        /// <summary>
        /// Tests if an exception is thrown when the ID is negative or zero.
        /// </summary>
        [Test]
        public void TestExceptionIdNegativeOrZero()
        {
            // Act & Assert
            var ex = Assert.Throws<Exception>(() => new Account(-2, 5));
            Assert.That(ex.Message, Is.EqualTo("Id cannot be negaitve or zero"));
        }

        /// <summary>
        /// Tests if an exception is thrown when the balance is negative.
        /// </summary>
        [Test]
        public void TestExceptionBalanceNegative()
        {
            // Act & Assert
            var ex = Assert.Throws<Exception>(() => new Account(1, -25));
            Assert.That(ex.Message, Is.EqualTo("Balance cannot be negative"));
        }

        /// <summary>
        /// Tests if an exception is thrown for insufficient balance during withdrawal.
        /// </summary>
        [Test]
        public void TestInsufficientBalance()
        {
            // Act & Assert
            var ex = Assert.Throws<Exception>(() => account.Withdraw(35));
            Assert.That(ex.Message, Is.EqualTo("Insufficient balance"));
        }
    }
}
